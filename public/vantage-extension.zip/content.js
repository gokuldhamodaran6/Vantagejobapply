// Vantage — runs inside job application pages (every frame) only when you press "Fill with Vantage".
// It reads the form, fills it with your answers and tailored files, and never presses Submit for you.
(() => {
  if (window.__vantage) return;

  function extractInPage() {
  const W = window;
  // Some sign-in pages (e.g. Amazon's) build their forms inside web components: look inside open shadow roots too.
  const roots = [document];
  const walk = (root) => {
    for (const el of root.querySelectorAll("*")) {
      if (el.shadowRoot) {
        roots.push(el.shadowRoot);
        walk(el.shadowRoot);
      }
    }
  };
  walk(document);
  const qsa = (sel) => roots.flatMap((r) => [...r.querySelectorAll(sel)]);
  const rootOf = (el) => (el.getRootNode && el.getRootNode().querySelector ? el.getRootNode() : document);
  const text = (el) => {
    if (!el) return "";
    if (el.querySelector && el.querySelector("select, option, [role='listbox'], [role='option']")) {
      const c = el.cloneNode(true);
      c.querySelectorAll("select, option, [role='listbox'], [role='option'], ul[class*='dropdown' i]").forEach((n) => n.remove());
      return (c.textContent || "").replace(/\s+/g, " ").trim();
    }
    return (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
  };
  const visible = (el) => {
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    if (!(r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none")) return false;
    // Styled checkboxes/radios (Workday "I agree") keep the real input at opacity 0 under a drawn box.
    if (el.tagName === "INPUT" && /^(checkbox|radio)$/i.test(el.type)) return r.width >= 8 && r.height >= 8;
    return s.opacity !== "0";
  };
  // Bot traps (Workday's 1-pixel "beecatcher" box, honeypot fields) are never filled.
  const trap = (el) => {
    const r = el.getBoundingClientRect();
    return (el.tagName === "INPUT" && !/^(checkbox|radio|file)$/i.test(el.type) && (r.width < 4 || r.height < 4)) || /honeypot|beecatcher|bot.?trap/i.test(`${el.name} ${el.id} ${el.getAttribute("data-automation-id") || ""}`);
  };
  let n = W.__vantageN || 0;
  const tag = (el) => {
    if (!el.dataset.vantageId) el.dataset.vantageId = `f${n++}`;
    return el.dataset.vantageId;
  };
  const containerLabel = (el) => {
    let p = el.parentElement;
    for (let i = 0; i < 6 && p; i++, p = p.parentElement) {
      const l = p.querySelector(":scope > label, :scope > legend, :scope > [class*='label' i], :scope > [class*='question' i], :scope > div > label, :scope > h3, :scope > h4, :scope > p > strong");
      if (l && !l.contains(el) && text(l).length > 1) return text(l);
    }
    return "";
  };
  const labelOf = (el) => {
    const parts = [];
    const lb = el.getAttribute("aria-labelledby");
    if (lb) parts.push(lb.split(/\s+/).map((id) => text(rootOf(el).getElementById ? rootOf(el).getElementById(id) : document.getElementById(id))).join(" "));
    if (el.id) {
      try {
        const l = rootOf(el).querySelector(`label[for="${CSS.escape(el.id)}"]`);
        if (l) parts.push(text(l));
      } catch { /* ignore */ }
    }
    const wrap = el.closest("label");
    if (wrap && !parts.length) parts.push(text(wrap));
    if (el.getAttribute("aria-label") && !parts.length) parts.push(el.getAttribute("aria-label"));
    if (!parts.join("").trim()) parts.push(containerLabel(el));
    if (!parts.join("").trim() && el.placeholder) parts.push(el.placeholder);
    // aria-labelledby and <label for> usually point at the same text: keep each distinct label once.
    const key = (x) => x.toLowerCase().replace(/[^a-z0-9]/g, "");
    const uniq = [];
    for (const p of parts.map((x) => (x || "").replace(/\s+/g, " ").trim()).filter(Boolean)) {
      if (!uniq.some((u) => key(u) === key(p) || key(u).includes(key(p)) || key(p).includes(key(u)))) uniq.push(p);
      else if (uniq.length && key(p).length > key(uniq[uniq.length - 1]).length && key(p).includes(key(uniq[uniq.length - 1]))) uniq[uniq.length - 1] = p;
    }
    const t = uniq.join(" ").trim();
    return t.slice(0, 300);
  };
  const required = (el, label) => el.required || el.getAttribute("aria-required") === "true" || /\*\s*$|\*\s|\(required\)/i.test(label);
  const fields = [];
  const seenGroups = new Set();

  for (const el of qsa("input, textarea, select, [role='combobox'], button[aria-haspopup='listbox']")) {
    const isListButton = el.tagName === "BUTTON" && el.getAttribute("aria-haspopup") === "listbox";
    const type = isListButton ? "combobox" : (el.tagName === "INPUT" ? el.getAttribute("type") || "text" : el.tagName).toLowerCase();
    if (["hidden", "submit", "button", "image", "reset", "search"].includes(type)) continue;
    if (el.disabled || el.readOnly && type !== "file") continue;
    const isFile = type === "file";
    if (!isFile && type !== "radio" && type !== "checkbox" && !visible(el)) continue;
    if (!isFile && trap(el)) continue;
    if (el.closest("[aria-hidden='true']") && !isFile) continue;
    // Site search boxes (job keyword / location search in the header) are not part of the application.
    if (el.closest("header, nav, [role='search'], [role='banner'], form[action*='search' i]") || /search|keyword|query/i.test(`${el.id} ${el.name} ${el.getAttribute("placeholder") || ""} ${el.getAttribute("aria-label") || ""}`)) continue;
    // react-select puts the real input inside a combobox container; skip duplicates
    if (el.tagName === "INPUT" && el.closest("[role='combobox']") && el.getAttribute("role") !== "combobox") continue;

    if (type === "radio") {
      const group = el.name || el.closest("fieldset, [role='radiogroup']")?.id || "";
      if (!group || seenGroups.has(group)) continue;
      seenGroups.add(group);
      const radios = [...rootOf(el).querySelectorAll(`input[type='radio'][name="${CSS.escape(el.name)}"]`)];
      const fs = el.closest("fieldset, [role='radiogroup']");
      const label = (fs && text(fs.querySelector("legend"))) || containerLabel(fs || el) || el.name;
      fields.push({ id: tag(el), type: "radio", label, name: el.name, required: radios.some((r) => r.required) || /\*/.test(label), options: radios.map((r) => labelOf(r) || r.value) });
      continue;
    }
    const label = labelOf(el);
    if (type === "checkbox") {
      // Several checkboxes sharing one name are one question with options (e.g. Lever: "Previously employed? No / Yes - Intern").
      const group = el.name ? [...rootOf(el).querySelectorAll(`input[type='checkbox'][name="${CSS.escape(el.name)}"]`)] : [];
      if (group.length >= 2) {
        if (seenGroups.has(`cb:${el.name}`)) continue;
        seenGroups.add(`cb:${el.name}`);
        const box = el.closest("fieldset, [role='group'], ul, ol") || el.parentElement?.parentElement || el;
        const gl = (box.tagName === "FIELDSET" && text(box.querySelector("legend"))) || containerLabel(box) || el.name;
        fields.push({ id: tag(el), type: "checkboxes", label: gl, name: el.name, required: group.some((c) => c.required) || /\*/.test(gl), options: group.map((c) => labelOf(c) || c.value), value: group.filter((c) => c.checked).map((c) => labelOf(c) || c.value).join("; ") });
        continue;
      }
      fields.push({ id: tag(el), type: "checkbox", label, name: el.name, required: required(el, label), checked: el.checked });
      continue;
    }
    if (el.tagName === "SELECT") {
      fields.push({ id: tag(el), type: "select", label, name: el.name, required: required(el, label), options: [...el.options].slice(0, 600).map((o) => (o.textContent || o.value || "").replace(/\s+/g, " ").trim().slice(0, 140)).filter(Boolean), value: el.value });
      continue;
    }
    if (el.getAttribute("role") === "combobox" || el.getAttribute("aria-haspopup") === "listbox") {
      // react-select and similar show the chosen value in a sibling element; the input itself stays empty.
      const shell = el.closest("[class*='select__control'], [class*='-control'], [class*='Select-control'], [class*='select-shell'], [class*='container']") || el.parentElement?.parentElement;
      const shown = shell && shell.querySelector("[class*='single-value'], [class*='singleValue'], [class*='multi-value__label'], [class*='Select-value-label']");
      const cur = el.tagName === "BUTTON" ? text(el) : (shown ? text(shown) : el.value);
      fields.push({ id: tag(el), type: "combobox", label: label || containerLabel(el), name: el.name || el.getAttribute("data-automation-id") || "", required: required(el, label || containerLabel(el)), options: [], value: /select one|^select$|^choose/i.test(cur) ? "" : cur });
      continue;
    }
    const t = el.tagName === "TEXTAREA" ? "textarea" : ["email", "tel", "url", "number", "date", "password", "file"].includes(type) ? type : "text";
    fields.push({ id: tag(el), type: t, label, name: el.name || el.getAttribute("data-automation-id") || "", required: required(el, label), placeholder: el.placeholder || "", value: t === "file" ? "" : el.value, accept: el.getAttribute("accept") || "", maxlen: el.maxLength > 0 ? el.maxLength : undefined, otp: el.autocomplete === "one-time-code" || undefined });
  }

  // Yes/No button groups (Ashby and others) — buttons inside a labelled container.
  for (const box of qsa("fieldset, [class*='question' i], [class*='field' i]")) {
    const btns = [...box.querySelectorAll(":scope button, :scope [role='button']")].filter((b) => visible(b) && /^(yes|no)$/i.test(text(b)));
    if (btns.length !== 2 || box.querySelector("input:not([type='hidden']), select, textarea")) continue;
    const label = text(box.querySelector("legend, label, [class*='label' i], [class*='title' i]")) || containerLabel(btns[0]);
    if (!label) continue;
    fields.push({ id: tag(box), type: "buttons", label, required: /\*/.test(label), options: btns.map(text), value: btns.find((b) => b.getAttribute("aria-pressed") === "true" || /selected|active/i.test(b.className))?.innerText || "" });
  }
  W.__vantageN = n;
  return fields;
}

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const norm = (s) => String(s || "").toLowerCase().replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();
  const closest = (options, want) => {
    const w = norm(want);
    if (!w) return null;
    return options.find((o) => norm(o) === w) || options.find((o) => norm(o).startsWith(w)) || options.find((o) => norm(o).includes(w)) || options.find((o) => w.includes(norm(o)) && norm(o).length > 2) || null;
  };
  const byId = (id) => document.querySelector(`[data-vantage-id="${CSS.escape(id)}"]`);
  const labelFor = (input) => {
    const id = input.getAttribute("id");
    const l = id ? document.querySelector(`label[for="${CSS.escape(id)}"]`) : null;
    return ((l && l.innerText) || input.closest("label")?.innerText || input.value || "").trim();
  };

  // React, Vue and Angular forms only notice values set through the native setter plus input/change events.
  function setNative(el, value, blur = true) {
    const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : el.tagName === "SELECT" ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    el.focus();
    if (setter) setter.call(el, value);
    else el.value = value;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    if (blur) el.dispatchEvent(new Event("blur", { bubbles: true }));
  }
  function check(el, on = true) {
    if (el.checked === on) return;
    const lab = el.id ? document.querySelector(`label[for="${CSS.escape(el.id)}"]`) : null;
    (lab || el).click();
    if (el.checked !== on) {
      el.checked = on;
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }
  }
  function ownList(el) {
    const ids = `${el.getAttribute("aria-controls") || ""} ${el.getAttribute("aria-owns") || ""}`.trim().split(/\s+/).filter(Boolean);
    for (const id of ids) {
      const l = document.getElementById(id);
      if (l) return [...l.querySelectorAll("[role='option'], li")].filter((o) => o.offsetParent !== null);
    }
    const lists = [...document.querySelectorAll("[role='listbox'], [class*='menu-list' i], [class*='select__menu' i], ul[class*='dropdown' i]")].filter((l) => l.offsetParent !== null);
    if (!lists.length) return [];
    const r = el.getBoundingClientRect();
    lists.sort((a, b) => Math.abs(a.getBoundingClientRect().top - r.bottom) - Math.abs(b.getBoundingClientRect().top - r.bottom));
    return [...lists[0].querySelectorAll("[role='option'], li, [class*='option' i]")].filter((o) => o.offsetParent !== null);
  }
  const STATE_NAMES = { AL: "alabama", AK: "alaska", AZ: "arizona", AR: "arkansas", CA: "california", CO: "colorado", CT: "connecticut", DE: "delaware", DC: "district of columbia", FL: "florida", GA: "georgia", HI: "hawaii", ID: "idaho", IL: "illinois", IN: "indiana", IA: "iowa", KS: "kansas", KY: "kentucky", LA: "louisiana", ME: "maine", MD: "maryland", MA: "massachusetts", MI: "michigan", MN: "minnesota", MS: "mississippi", MO: "missouri", MT: "montana", NE: "nebraska", NV: "nevada", NH: "new hampshire", NJ: "new jersey", NM: "new mexico", NY: "new york", NC: "north carolina", ND: "north dakota", OH: "ohio", OK: "oklahoma", OR: "oregon", PA: "pennsylvania", RI: "rhode island", SC: "south carolina", SD: "south dakota", TN: "tennessee", TX: "texas", UT: "utah", VT: "vermont", VA: "virginia", WA: "washington", WV: "west virginia", WI: "wisconsin", WY: "wyoming", ON: "ontario", BC: "british columbia", QC: "quebec", AB: "alberta" };
  function chooseOption(texts, want) {
  if (!texts.length || !want) return null;
  const hit = closest(texts, want);
  if (hit) return hit;
  const parts = want.split(",").map((x) => x.trim()).filter(Boolean);
  if (parts.length >= 2) {
    const city = norm(parts[0]);
    const region = STATE_NAMES[parts[1].toUpperCase()] || norm(parts[1]);
    const sameCity = texts.filter((t) => norm(t.split(",")[0]) === city);
    return sameCity.find((t) => norm(t).includes(region)) || (sameCity.length === 1 ? sameCity[0] : null);
  }
  return null;
}
  function suggestions(el) {
    const own = ownList(el);
    if (own.length) return own;
    return [...document.querySelectorAll(".pac-item, [class*='dropdown-results' i] > *, [class*='dropdown-location' i], [class*='suggestion' i], [class*='autocomplete' i] li, [class*='typeahead' i] li")].filter((o) => o.offsetParent !== null);
  }
  async function readOptions(id) {
    const el = byId(id);
    if (!el) return [];
    el.scrollIntoView({ block: "center" });
    el.click();
    el.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
    await sleep(500);
    const out = [...new Set(ownList(el).map((o) => (o.innerText || "").replace(/\s+/g, " ").trim()).filter((t) => t && t.length < 160 && !/^(no (options|results)|loading)/i.test(t)))].slice(0, 400);
    el.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    document.body.click();
    await sleep(120);
    return out;
  }
  async function typeInto(el, text) {
    el.focus();
    setNative(el, "", false);
    for (const ch of text.slice(0, 60)) {
      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
      setter ? setter.call(el, el.value + ch) : (el.value += ch);
      el.dispatchEvent(new InputEvent("input", { bubbles: true, data: ch, inputType: "insertText" }));
      await sleep(25);
    }
  }

  /** Fill one field. Returns true when the page shows the value. */
  async function fill(f, plan, file) {
    const el = byId(f.id);
    if (!el) return false;
    try {
      if (plan.file) {
        if (!file) return false;
        const bytes = Uint8Array.from(atob(file.base64), (c) => c.charCodeAt(0));
        const dt = new DataTransfer();
        dt.items.add(new File([bytes], file.name, { type: file.mimeType || "application/pdf" }));
        el.files = dt.files;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
        await sleep(1200);
        return el.files?.length > 0;
      }
      if (f.type === "checkbox") {
        if (plan.check) check(el, true);
        return true;
      }
      if (f.type === "checkboxes") {
        const wants = String(plan.value || "").split(/;\s*/).map(norm).filter(Boolean);
        let hit = 0;
        for (const b of document.querySelectorAll(`input[type='checkbox'][name="${CSS.escape(f.name || "")}"]`)) {
          const lab = norm(labelFor(b));
          if (wants.some((w) => lab === w || lab.startsWith(w))) { check(b, true); hit++; }
        }
        return hit > 0;
      }
      if (f.type === "radio") {
        for (const r of document.querySelectorAll(`input[type='radio'][name="${CSS.escape(f.name || "")}"]`)) {
          const lab = labelFor(r);
          if (norm(lab) === norm(plan.value) || norm(r.value) === norm(plan.value) || (lab && norm(lab).startsWith(norm(plan.value)))) { check(r, true); return true; }
        }
        return false;
      }
      if (f.type === "select") {
        const opts = [...el.options];
        const hit = closest(opts.map((o) => o.text.trim()), plan.value);
        const opt = opts.find((o) => o.text.trim() === hit);
        if (!opt) return false;
        setNative(el, opt.value);
        return true;
      }
      if (f.type === "buttons") {
        const btn = [...el.querySelectorAll("button, [role='button']")].find((b) => norm(b.innerText) === norm(plan.value));
        if (!btn) return false;
        btn.click();
        return true;
      }
      if (f.type === "combobox") {
        const want = String(plan.value || "");
        el.scrollIntoView({ block: "center" });
        const isButton = el.tagName === "BUTTON";
        const queries = isButton ? [""] : [...new Set([want, want.split(",")[0].trim(), want.split(/\s+/)[0]].filter((q) => q && q.length >= 2))].slice(0, 3);
        for (const q of queries) {
          el.click();
          el.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
          await sleep(250);
          if (!isButton) await typeInto(el, q);
          await sleep(isButton ? 400 : 1000);
          const opts = ownList(el);
          const texts = opts.map((o) => (o.innerText || "").replace(/\s+/g, " ").trim());
          const pick = closest(texts.filter((t) => t && !/^(no (options|results)|loading|type to search)/i.test(t)), want);
          if (pick) {
            const o = opts[texts.indexOf(pick)];
            o.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
            o.click();
            await sleep(250);
            return true;
          }
        }
        if (!isButton) setNative(el, "");
        el.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
        return false;
      }
      if (f.type === "text" && /location|city|where (do )?you (live|are based)/i.test(f.label)) {
        // Type-ahead location boxes (Lever, Google Places): type, then pick the matching suggestion.
        const want = String(plan.value);
        for (const q of [...new Set([want, want.split(",")[0].trim()])]) {
          await typeInto(el, q);
          await sleep(900);
          const opts = suggestions(el);
          const texts = opts.map((o) => (o.innerText || "").replace(/\s+/g, " ").trim());
          const pick = chooseOption(texts, want);
          if (pick) {
            const o = opts[texts.indexOf(pick)];
            o.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
            o.click();
            await sleep(250);
            return true;
          }
          if (!opts.length) break; // a plain text box: keep what was typed
        }
        setNative(el, want);
        return true;
      }
      setNative(el, String(plan.value ?? ""));
      return true;
    } catch {
      return false;
    }
  }

  /** What the page says about the job, so Vantage can tailor for it. */
  function info() {
    const meta = (p) => document.querySelector(`meta[property="${p}"], meta[name="${p}"]`)?.getAttribute("content") || "";
    const h1 = (document.querySelector("h1")?.innerText || "").trim();
    const title = (h1 && h1.length < 140 ? h1 : "") || meta("og:title") || document.title;
    const ld = [...document.querySelectorAll("script[type='application/ld+json']")].map((s) => { try { return JSON.parse(s.textContent || ""); } catch { return null; } }).flat().find((x) => x && x["@type"] === "JobPosting");
    return {
      url: location.href,
      title: (ld?.title || title || "").replace(/\s*[|–-]\s*(careers?|jobs?).*$/i, "").trim(),
      company: ld?.hiringOrganization?.name || meta("og:site_name") || "",
      location: ld?.jobLocation?.address?.addressLocality || "",
      description: (ld?.description ? ld.description.replace(/<[^>]+>/g, " ") : (document.querySelector("main, article, [class*='description' i]") || document.body).innerText).slice(0, 15000),
    };
  }

  const CONFIRM = /thank(s| you) for (applying|your application|submitting)|application (has been |was )?(received|submitted)|we('ve| have) received your application|successfully (submitted|applied)|your application is complete/i;
  const isConfirmation = () => CONFIRM.test(document.body?.innerText?.slice(0, 20000) || "") || /\/(confirmation|thank-?you|applied|success)\b/i.test(location.pathname);

  // After the user presses a submit-like button, watch for the confirmation (single-page apps don't reload).
  if (window === window.top) {
    document.addEventListener("click", (e) => {
      const b = e.target instanceof Element ? e.target.closest("button, input[type='submit'], [role='button']") : null;
      if (!b || !/submit|apply|send|finish/i.test(b.innerText || b.value || "")) return;
      let n = 0;
      const t = setInterval(() => {
        if (isConfirmation()) { clearInterval(t); chrome.runtime.sendMessage({ type: "confirmation" }).catch(() => {}); }
        if (++n > 30) clearInterval(t);
      }, 1000);
    }, true);
  }

  /* ---------- the panel (top frame only) ---------- */
  let host = null;
  let root = null;
  const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
  const CSS_TEXT = `
    :host { all: initial; }
    .p { position: fixed; right: 18px; bottom: 18px; width: 360px; max-height: 78vh; overflow: auto; z-index: 2147483647; background: #fff; color: #10142a;
      border: 1px solid #e3e6ee; border-radius: 16px; box-shadow: 0 18px 50px rgba(16,20,42,.18); font: 14px/1.45 -apple-system, BlinkMacSystemFont, "Segoe UI", Inter, sans-serif; }
    .h { display: flex; align-items: center; gap: 8px; padding: 12px 14px; border-bottom: 1px solid #eef0f4; font-weight: 700; }
    .logo { width: 22px; height: 22px; border-radius: 6px; background: #2f5beb; color: #fff; display: grid; place-items: center; font-size: 13px; }
    .x { margin-left: auto; border: 0; background: none; font-size: 18px; color: #8a90a2; cursor: pointer; }
    .b { padding: 14px; }
    .job { font-weight: 700; } .muted { color: #6b7185; font-size: 12.5px; }
    .steps { margin: 12px 0 0; padding: 0; list-style: none; }
    .steps li { display: flex; gap: 8px; align-items: flex-start; padding: 4px 0; }
    .dot { width: 8px; height: 8px; border-radius: 50%; margin-top: 6px; flex: none; background: #d4d8e2; }
    .done .dot { background: #22a05b; } .now .dot { background: #2f5beb; animation: pulse 1s infinite; }
    @keyframes pulse { 50% { opacity: .35; } }
    .warn { margin-top: 10px; padding: 8px 10px; border-radius: 10px; background: #fdecec; color: #a22; font-size: 13px; font-weight: 600; }
    .ok { margin-top: 10px; padding: 8px 10px; border-radius: 10px; background: #e8f6ee; color: #17713f; font-size: 13px; font-weight: 600; }
    .q { margin-top: 12px; } .q label { display: block; font-weight: 600; font-size: 13px; margin-bottom: 4px; }
    .q input, .q textarea, .q select { width: 100%; box-sizing: border-box; border: 1px solid #d9dce5; border-radius: 9px; padding: 8px 10px; font: inherit; }
    .q textarea { min-height: 70px; }
    .row { display: flex; gap: 8px; margin-top: 14px; flex-wrap: wrap; }
    .btn { border: 0; border-radius: 10px; padding: 9px 14px; font: inherit; font-weight: 700; cursor: pointer; background: #2f5beb; color: #fff; }
    .btn.g { background: #f1f3f8; color: #10142a; }
  `;
  function panel(state) {
    if (window !== window.top) return;
    if (!host) {
      host = document.createElement("div");
      host.id = "vantage-panel";
      document.documentElement.appendChild(host);
      root = host.attachShadow({ mode: "closed" });
    }
    if (!state) { host.remove(); host = null; return; }
    const steps = (state.steps || []).map((s) => `<li class="${s.state}"><span class="dot"></span><span>${esc(s.text)}</span></li>`).join("");
    const qs = (state.missing || []).map((m, i) => {
      const id = `q${i}`;
      const sel = (o) => (m.suggest && o === m.suggest ? " selected" : "");
      const input = m.options?.length
        ? `<select id="${id}"><option value="">Choose…</option>${m.options.map((o) => `<option${sel(o)}>${esc(o)}</option>`).join("")}</select>`
        : m.type === "textarea" || m.label.length > 90 ? `<textarea id="${id}">${esc(m.suggest || "")}</textarea>` : `<input id="${id}" value="${esc(m.suggest || "")}" />`;
      const note = m.locked ? `<div class="muted" style="margin-top:4px">A statement in your name — Vantage never guesses it.${m.suggest ? " Pre-selected from your profile; check it's true for this exact question." : ""}</div>` : "";
      return `<div class="q"><label for="${id}">${esc(m.label)}</label>${note}${input}</div>`;
    }).join("");
    root.innerHTML = `<style>${CSS_TEXT}</style><div class="p" role="dialog" aria-label="Vantage">
      <div class="h"><span class="logo">V</span> Vantage <button class="x" aria-label="Close">×</button></div>
      <div class="b">
        ${state.job ? `<div class="job">${esc(state.job.title)}</div><div class="muted">${esc(state.job.company)}${state.match ? ` · ${state.match}% match` : ""}</div>` : ""}
        ${state.ghost ? `<div class="warn">${state.ghost.level === "high" ? "Likely ghost job" : "Might be a ghost job"}: ${esc(state.ghost.reasons.join(" · "))}</div>` : ""}
        ${state.note ? `<div class="${state.noteTone || "ok"}">${esc(state.note)}</div>` : ""}
        <ul class="steps">${steps}</ul>
        ${qs ? `<div style="margin-top:12px;font-weight:700">Only you can answer ${state.missing.length === 1 ? "this" : "these"}</div><div class="muted">Answer once — Vantage remembers it for every future application.</div>${qs}` : ""}
        <div class="row">${(state.buttons || []).map((b) => `<button class="btn ${b.ghost ? "g" : ""}" data-a="${esc(b.action)}">${esc(b.text)}</button>`).join("")}</div>
      </div></div>`;
    root.querySelector(".x").onclick = () => chrome.runtime.sendMessage({ type: "panel", action: "close" });
    root.querySelectorAll("[data-a]").forEach((b) => {
      b.onclick = () => {
        const answers = (state.missing || []).map((m, i) => ({ ...m, answer: root.getElementById(`q${i}`)?.value || "" }));
        chrome.runtime.sendMessage({ type: "panel", action: b.getAttribute("data-a"), answers });
      };
    });
  }

  window.__vantage = { extract: () => extractInPage(), readOptions, fill, info, isConfirmation, panel };
})();
